# Add Rich Graphics to Your SwiftUI App

Make your apps stand out by adding background materials, vibrancy, custom graphics, and animations.

## Overview

- Note: This sample code project is associated with WWDC21 session 10021: [Add Rich Graphics to Your SwiftUI App](https://developer.apple.com/wwdc21/10021/).
